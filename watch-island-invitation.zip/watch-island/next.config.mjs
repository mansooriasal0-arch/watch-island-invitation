export default {reactStrictMode:true};
